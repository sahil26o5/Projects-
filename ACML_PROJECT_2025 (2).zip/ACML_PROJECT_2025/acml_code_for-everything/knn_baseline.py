import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, f1_score

# Load and prepare data
df = pd.read_csv("cbc_data_v4_preprocessed.csv")
label_cols = ['Anemia', 'Leukemia', 'Thrombocytopenia', 'Leukemia_with_thrombocytopenia', 'Healthy']
df["Diagnosis"] = np.argmax(df[label_cols].values, axis=1)

X = df.drop(columns=label_cols).values
y = df["Diagnosis"].values

X_train, X_test, y_train, y_test = train_test_split(X, y, stratify=y, test_size=0.3, random_state=42)

# Train k-NN classifier
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(X_train, y_train)
y_pred = knn.predict(X_test)

# Evaluate
print("k-NN Accuracy:", accuracy_score(y_test, y_pred))
print("F1 Score (macro):", f1_score(y_test, y_pred, average='macro'))
