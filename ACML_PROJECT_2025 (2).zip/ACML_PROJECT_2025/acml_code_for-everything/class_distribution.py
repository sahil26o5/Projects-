import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
# Convert one-hot to integer label
df = pd.read_csv("cbc_data_v4_preprocessed.csv")
label_cols = ['Anemia', 'Leukemia', 'Thrombocytopenia', 'Leukemia_with_thrombocytopenia', 'Healthy']
df["Diagnosis"] = np.argmax(df[label_cols].values, axis=1)

class_counts = df["Diagnosis"].value_counts().sort_index()
class_labels = ["Anemia", "Leukemia", "Thrombocytopenia", "Leukemia+Thrombocytopenia", "Healthy"]

plt.figure(figsize=(8, 4))
sns.barplot(x=class_labels, y=class_counts.values)
plt.ylabel("Number of Samples")
plt.title("Diagnosis Class Distribution")
plt.xticks(rotation=15)
plt.tight_layout()
plt.show()


