import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_csv("cbc_data_v4_preprocessed.csv")
label_cols = ['Anemia', 'Leukemia', 'Thrombocytopenia', 'Leukemia_with_thrombocytopenia', 'Healthy']
cbc_features = df.drop(columns=label_cols)
cbc_features["Diagnosis"] = df[label_cols].idxmax(axis=1)
plt.figure(figsize=(12, 8))
corr = cbc_features.drop(columns=["Diagnosis"]).corr()
sns.heatmap(corr, annot=True, cmap='coolwarm', fmt=".2f")
plt.title("Correlation Between CBC Features")
plt.tight_layout()
plt.show()

