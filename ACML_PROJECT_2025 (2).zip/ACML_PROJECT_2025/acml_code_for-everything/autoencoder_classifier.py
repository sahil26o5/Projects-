import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, f1_score
import matplotlib.pyplot as plt
from torch.utils.data import DataLoader, TensorDataset

# ======= Load Data =======
df = pd.read_csv("cbc_data_v4_preprocessed.csv")
label_cols = ['Anemia', 'Leukemia', 'Thrombocytopenia', 'Leukemia_with_thrombocytopenia', 'Healthy']
X = df.drop(columns=label_cols).values
y = np.argmax(df[label_cols].values, axis=1)

# ======= Train/Val/Test Split =======
X_train, X_temp, y_train, y_temp = train_test_split(X, y, test_size=0.3, stratify=y, random_state=42)
X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=0.5, stratify=y_temp, random_state=42)

X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
X_val_tensor = torch.tensor(X_val, dtype=torch.float32)
X_test_tensor = torch.tensor(X_test, dtype=torch.float32)
y_train_tensor = torch.tensor(y_train, dtype=torch.long)
y_val_tensor = torch.tensor(y_val, dtype=torch.long)
y_test_tensor = torch.tensor(y_test, dtype=torch.long)

train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)

# ======= Autoencoder Definition =======
class Autoencoder(nn.Module):
    def __init__(self, latent_dim=10):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(14, 10),
            nn.ReLU(),
            nn.Linear(10, latent_dim)
        )
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, 10),
            nn.ReLU(),
            nn.Linear(10, 14)
        )

    def forward(self, x):
        z = self.encoder(x)
        x_recon = self.decoder(z)
        return x_recon

# ======= Classifier Definition =======
class Classifier(nn.Module):
    def __init__(self, latent_dim=5):
        super().__init__()
        self.classifier = nn.Sequential(
            nn.Linear(latent_dim, 32),
            nn.ReLU(),
            nn.Linear(32, 5)
        )

    def forward(self, z):
        return self.classifier(z)

# ======= Training Autoencoder =======
latent_dim = 5  # 🔁 Try 3, 5, 10 here
ae = Autoencoder(latent_dim=latent_dim)
ae_criterion = nn.MSELoss()
ae_optimizer = optim.Adam(ae.parameters(), lr=0.001, weight_decay=1e-4)  # L2 regularization

ae_epochs = 100
ae_loss_list = []
for epoch in range(ae_epochs):
    ae.train()
    total_loss = 0
    for xb, _ in train_loader:
        ae_optimizer.zero_grad()
        recon = ae(xb)
        loss = ae_criterion(recon, xb)
        loss.backward()
        ae_optimizer.step()
        total_loss += loss.item()
    avg_loss = total_loss / len(train_loader)
    ae_loss_list.append(avg_loss)
    print(f"AE Epoch {epoch+1}/{ae_epochs}, Loss: {avg_loss:.4f}")

# Plot AE loss
plt.plot(ae_loss_list)
plt.title("Autoencoder Reconstruction Loss (MSE)")
plt.xlabel("Epoch")
plt.ylabel("Loss")
plt.grid(True)
plt.tight_layout()
plt.show()

# ======= Train Classifier on Encoded Data =======
classifier = Classifier(latent_dim=latent_dim)
clf_criterion = nn.CrossEntropyLoss()
clf_optimizer = optim.Adam(classifier.parameters(), lr=0.001, weight_decay=1e-4)

clf_train_loss_list = []
clf_val_loss_list = []
clf_epochs = 30

for epoch in range(clf_epochs):
    classifier.train()
    train_loss = 0.0
    for xb, yb in train_loader:
        clf_optimizer.zero_grad()
        z = ae.encoder(xb)
        preds = classifier(z)
        loss = clf_criterion(preds, yb)
        loss.backward()
        clf_optimizer.step()
        train_loss += loss.item()
    train_loss /= len(train_loader)
    clf_train_loss_list.append(train_loss)

    classifier.eval()
    with torch.no_grad():
        z_val = ae.encoder(X_val_tensor)
        val_preds = classifier(z_val)
        val_loss = clf_criterion(val_preds, y_val_tensor).item()
        clf_val_loss_list.append(val_loss)

    print(f"Classifier Epoch {epoch+1}/{clf_epochs}, Train Loss: {train_loss:.4f}, Val Loss: {val_loss:.4f}")

# Plot classifier loss curve
plt.plot(clf_train_loss_list, label="Train Loss")
plt.plot(clf_val_loss_list, label="Val Loss")
plt.title("Classifier Loss Over Epochs (Autoencoder)")
plt.xlabel("Epoch")
plt.ylabel("CrossEntropy Loss")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

# ======= Evaluation =======
classifier.eval()
with torch.no_grad():
    z_test = ae.encoder(X_test_tensor)
    test_outputs = classifier(z_test)
    test_preds = torch.argmax(test_outputs, dim=1).numpy()

accuracy = accuracy_score(y_test, test_preds)
f1 = f1_score(y_test, test_preds, average='macro')

print("\n===== Autoencoder + Classifier Evaluation =====")
print(f"Accuracy: {accuracy:.4f}")
print(f"Macro F1 Score: {f1:.4f}")
print("\nClassification Report:")
print(classification_report(y_test, test_preds, zero_division=1))
print("Confusion Matrix:")
print(confusion_matrix(y_test, test_preds))
