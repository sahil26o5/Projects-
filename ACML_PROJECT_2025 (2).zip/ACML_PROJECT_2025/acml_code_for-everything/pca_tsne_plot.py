import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE

# === Load data ===
df = pd.read_csv("cbc_data_v4_preprocessed.csv")

# === Define label columns ===
label_cols = ['Anemia', 'Leukemia', 'Thrombocytopenia', 'Leukemia_with_thrombocytopenia', 'Healthy']
df["Diagnosis"] = np.argmax(df[label_cols].values, axis=1)

# === Extract features (remove label columns) ===
X = df.drop(columns=label_cols).values
y = df["Diagnosis"].values

# === PCA ===
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X)

plt.figure(figsize=(6, 5))
sns.scatterplot(x=X_pca[:, 0], y=X_pca[:, 1], hue=y, palette='tab10')
plt.title("PCA Projection of CBC Data")
plt.show()

# === t-SNE ===
tsne = TSNE(n_components=2, perplexity=30, random_state=42)
X_tsne = tsne.fit_transform(X)

plt.figure(figsize=(6, 5))
sns.scatterplot(x=X_tsne[:, 0], y=X_tsne[:, 1], hue=y, palette='tab10')
plt.title("t-SNE Projection of CBC Data")
plt.show()
