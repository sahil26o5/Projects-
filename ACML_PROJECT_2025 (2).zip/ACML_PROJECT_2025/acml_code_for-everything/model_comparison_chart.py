import matplotlib.pyplot as plt
import numpy as np

# ==== Replace these with your actual values ====
model_names = [
    "MLP (No L2)",
    "MLP (+ L2)",
    "AE (dim=3)",
    "AE (dim=5)",
    "AE (dim=10)"
]

accuracies = [0.684, 0.591, 0.658, 0.720, 0.658]
f1_scores = [0.57, 0.56, 0.21, 0.27, 0.21]

x = np.arange(len(model_names))
width = 0.35

fig, ax = plt.subplots(figsize=(10, 6))
acc_bars = ax.bar(x - width/2, accuracies, width, label='Accuracy', color='steelblue')
f1_bars = ax.bar(x + width/2, f1_scores, width, label='F1 Score', color='darkorange')

# Add text labels above bars
def autolabel(bars):
    for bar in bars:
        height = bar.get_height()
        ax.annotate(f'{height:.2f}',
                    xy=(bar.get_x() + bar.get_width() / 2, height),
                    xytext=(0, 3), textcoords="offset points",
                    ha='center', va='bottom', fontsize=9)

autolabel(acc_bars)
autolabel(f1_bars)

ax.set_ylabel('Score')
ax.set_title('Model Comparison: Accuracy vs Macro F1 Score')
ax.set_xticks(x)
ax.set_xticklabels(model_names, rotation=30, ha='right')
ax.legend()
ax.grid(True, axis='y', linestyle='--', alpha=0.7)

plt.tight_layout()
plt.show()
