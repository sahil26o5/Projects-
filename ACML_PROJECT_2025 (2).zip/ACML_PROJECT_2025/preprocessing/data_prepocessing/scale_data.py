from sklearn.preprocessing import MinMaxScaler
import pandas as pd

# --- Scaling Functionality ---
def scale_data(data, output_file='data/cbc_data_v4_scaled.csv'):
    scaler = MinMaxScaler()
    
    # Select numerical columns for scaling
    numerical_columns = ['WBC', 'LYMp', 'NEUTp', 'LYMn', 'NEUTn', 'RBC', 'HGB', 
                         'HCT', 'MCV', 'MCH', 'MCHC', 'PLT', 'PDW', 'PCT']
    
    # Scale the numerical columns
    data[numerical_columns] = scaler.fit_transform(data[numerical_columns])
    
    # Save the scaled dataset
    data.to_csv(output_file, index=False)
    return data