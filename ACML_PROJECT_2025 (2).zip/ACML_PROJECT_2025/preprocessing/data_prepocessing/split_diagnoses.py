def split_diagnoses(data, output_file='data/cbc_data_v4_with_split_diagnoses.csv'):
    # Find unique Diagnosis types
    unique_diagnoses = data['Diagnosis'].unique()

    # Create a binary column for each anemia type
    for diag in unique_diagnoses:
        col_name = diag.strip().replace(' ', '_').replace('/', '_').replace('-', '_').replace('(', '').replace(')', '')
        data[col_name] = data['Diagnosis'].apply(lambda x: 1 if x == diag else 0)

    #Drop the original 'Diagnosis' column
    data_split = data.drop(columns=['Diagnosis'])

    # Save to file
    data_split.to_csv(output_file, index=False)

    # Return the processed DataFrame
    return data_split
