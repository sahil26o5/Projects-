def reduce_categories(data, output_file='data\cbc_data_v4_with_reduced_categories.csv'):
    # Replace diagnoses containing "Anemia" with "anemia"
    data['Diagnosis'] = data['Diagnosis'].str.replace(r'\b.*Anemia\b', 'Anemia', case=False, regex=True)

    # Save the updated CSV file
    data.to_csv(output_file, index=False)

    # Return the processed DataFrame
    return data