import pandas as pd
from split_diagnoses import split_diagnoses
from reduce_categories import reduce_categories
from scale_data import scale_data


def preprocess_data(input_file='data/diagnosed_cbc_data_v4.csv', output_file='data/cbc_data_v4_preprocessed.csv'):
    # Load the dataset
    data = pd.read_csv(input_file)

    #Reduce categories in the 'Diagnosis' column
    print("Reducing categories in the 'Diagnosis' column...")
    data = reduce_categories(data)

    #Split diagnoses into separate columns
    print("Splitting diagnoses into separate columns...")
    data = split_diagnoses(data)

    #Discretize the data
    print("Scaling the data...")
    data = scale_data(data)

    # Save the processed data to a new CSV file
    data.to_csv(output_file, index=False)
    print(f"Processed data saved as {output_file}")

    # Return the processed DataFrame
    return data

preprocess_data()



