import random
from reconchess import *
import chess
import chess.engine as chengine

# Path to Stockfish engine
STOCKFISH_PATH = './stockfish.exe'
MAX_BOARDS = 10000

'''
File Name:      random_sensing.py
Authors:        Kgetja Bruce Mphekgwane [2593733], Sahil Maharaj [2550404], Patel Suhail Mohmed Sadik [2583014]
Date:           May 9 , 2025



Brief:          COMS4033A AI Assignment 
Description:    Part 4: Report - Sub 1: baseline Agent
'''

class MyAgent(Player):
    def __init__(self):
        """Initialize the agent with empty state tracking and Stockfish engine."""
        self.color = None
        self.possible_boards = set()
        self.just_started = True
        self.engine = chengine.SimpleEngine.popen_uci(STOCKFISH_PATH, setpgrp=True)

    def handle_game_start(self, color, board, opponent_name):
        """Initialize game state with starting position."""
        self.color = color
        self.possible_boards = {board.fen()}
        self.just_started = True

    def handle_opponent_move_result(self, captured_my_piece, capture_square):
        """
                Update possible boards based on opponent's move result.
                - If opponent captured a piece, generate all possible capturing moves.
                - Otherwise, generate all non-capturing moves.
        """
        if self.just_started and self.color == chess.WHITE:
            self.just_started = False
            return
        self.just_started = False

        new_fens = set()
        for fen in self.possible_boards:
            board = chess.Board(fen)
            for move in board.pseudo_legal_moves:
                if captured_my_piece:
                    if board.is_capture(move) and move.to_square == capture_square:
                        new_board = board.copy()
                        new_board.push(move)
                        new_fens.add(new_board.fen())
                else:
                    if not board.is_capture(move):
                        new_board = board.copy()
                        new_board.push(move)
                        new_fens.add(new_board.fen())
        self.possible_boards = new_fens

    def choose_sense(self, sense_actions, move_actions, seconds_left):
        """
                Select a square to sense, prioritizing center squares for better information gain.
                - Avoids edges (files a/h, ranks 1/8) unless no other options exist.
        """
        non_edge_squares = [s for s in sense_actions
                            if 0 < chess.square_file(s) < 7 and 0 < chess.square_rank(s) < 7]
        return random.choice(non_edge_squares) if non_edge_squares else random.choice(sense_actions)

    def handle_sense_result(self, sense_result):
        """
                Filter possible boards to only those consistent with sensed squares.
                - Compares each board's pieces to the sensed results.
        """
        consistent = set()
        for fen in self.possible_boards:
            board = chess.Board(fen)
            if all(board.piece_at(square) == piece for square, piece in sense_result):
                consistent.add(fen)
        self.possible_boards = consistent

    def choose_move(self, move_actions, seconds_left):
        """
               Select the best move by:
               1. Handling belief state collapse (reset if no boards left).
               2. Capping boards based on time remaining.
               3. Voting across Stockfish suggestions from all possible boards.
               4. Falling back to random moves if no Stockfish suggestions exist.
        """
        if not self.possible_boards:
            print("⚠ No board states left — picking random move")
            self.possible_boards = {'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'}
            print("⚠ Reinitializing belief state due to complete collapse")

        # ⏱ Dynamically cap board states based on time left
        cap = min(MAX_BOARDS, 300 if seconds_left < 15 else 1000)
        if len(self.possible_boards) > cap:
            self.possible_boards = set(random.sample(list(self.possible_boards), cap))

        print(f"🧠 Choosing move from {len(self.possible_boards)} possible boards...")

        move_votes = {}
        limit = chengine.Limit(time=10 / len(self.possible_boards))

        for fen in self.possible_boards:
            board = chess.Board(fen)

            # Try direct king capture
            enemy_king_square = board.king(not self.color)
            if enemy_king_square:
                attackers = board.attackers(self.color, enemy_king_square)
                if attackers:
                    move = chess.Move(attackers.pop(), enemy_king_square)
                    if move in board.pseudo_legal_moves and move in move_actions:
                        move_str = move.uci()
                        move_votes[move_str] = move_votes.get(move_str, 0) + 1
                        continue

            # Otherwise use Stockfish
            try:
                result = self.engine.play(board, limit)
                if result.move and result.move in move_actions:
                    move_str = result.move.uci()
                    move_votes[move_str] = move_votes.get(move_str, 0) + 1
            except:
                continue

        if not move_votes:
            print("⚠ No legal Stockfish moves — picking random")
            return random.choice(move_actions)

        best_move_str = sorted(move_votes.items(), key=lambda x: (-x[1], x[0]))[0][0]
        return chess.Move.from_uci(best_move_str)

    def handle_move_result(self, requested_move, taken_move, captured_opponent_piece, capture_square):
        move = taken_move if taken_move else chess.Move.null()
        updated = set()
        for fen in self.possible_boards:
            board = chess.Board(fen)
            try:
                board.push(move)
                updated.add(board.fen())
            except:
                continue
        self.possible_boards = updated

    def handle_game_end(self, winner_color, win_reason, game_history):
        try:
            self.engine.quit()
        except chess.engine.EngineTerminatedError:
            print("⚠ Stockfish engine already terminated.")


# Optional helper function for RC runner
def create_bot():
    return MyAgent()
