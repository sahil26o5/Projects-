import random
from reconchess import *
import chess
import chess.engine as chengine
import numpy as np

'''
File Name:      improved_agent.py
Authors:        Kgetja Bruce Mphekgwane [2593733], Sahil Maharaj [2550404], Patel Suhail Mohmed Sadik [2583014]
Date:           May 11 , 2025

Brief:          COMS4033A AI Assignment 
Description:    Part 4: Report - Sub 2: Improved Agent
'''

STOCKFISH_PATH = './stockfish.exe'
MAX_BOARDS = 1000  # Cap to limit slowdown
ALPHA_BETA_DEPTH = 2  # Depth limit for pruning search

class ImprovedAgent(Player):
    def __init__(self):
        self.color = None
        self.belief_states = set()
        self.just_started = True
        self.engine = chengine.SimpleEngine.popen_uci(STOCKFISH_PATH, setpgrp=True)

    # Called at the beginning of the game
    def handle_game_start(self, color, board, opponent_name):
        self.color = color
        self.belief_states = {board.fen()}
        self.just_started = True

    # Updates belief states after opponent move feedback
    def handle_opponent_move_result(self, captured_my_piece, capture_square):
        if self.color == chess.WHITE and self.just_started:
            self.just_started = False
            return
        self.just_started = False

        updated = set()
        for fen in self.belief_states:
            board = chess.Board(fen)
            for move in board.pseudo_legal_moves:
                if captured_my_piece:
                    if board.is_capture(move) and move.to_square == capture_square:
                        b = board.copy()
                        b.push(move)
                        updated.add(b.fen())
                else:
                    if not board.is_capture(move):
                        b = board.copy()
                        b.push(move)
                        updated.add(b.fen())
        self.belief_states = updated

    # Chooses where to sense using entropy
    def choose_sense(self, sense_actions, move_actions, seconds_left):
        non_edge = [sq for sq in sense_actions if 0 < chess.square_file(sq) < 7 and 0 < chess.square_rank(sq) < 7]
        if not non_edge:
            return random.choice(sense_actions)

        samples = random.sample(list(self.belief_states), min(20, len(self.belief_states)))
        square_entropy = {}
        for square in non_edge:
            piece_counts = {}
            for fen in samples:
                board = chess.Board(fen)
                piece = board.piece_at(square)
                piece_counts[piece] = piece_counts.get(piece, 0) + 1
            # Compute entropy
            total = sum(piece_counts.values())
            entropy = -sum((count / total) * np.log2(count / total) for count in piece_counts.values())
            square_entropy[square] = entropy

        best_square = max(square_entropy.items(), key=lambda x: x[1])[0]
        return best_square

    # Refines belief states after sensing
    def handle_sense_result(self, sense_result):
        updated = set()
        for fen in self.belief_states:
            board = chess.Board(fen)
            if all(board.piece_at(sq) == piece for sq, piece in sense_result):
                updated.add(fen)
        self.belief_states = updated

    # Main move selection logic
    def choose_move(self, move_actions, seconds_left):
        if not self.belief_states:
            print("⚠ Belief state collapsed, reinitializing")
            self.belief_states = {'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'}

        if len(self.belief_states) > MAX_BOARDS:
            self.belief_states = set(random.sample(list(self.belief_states), MAX_BOARDS))

        print(f"🧠 Choosing move from {len(self.belief_states)} belief states")

        move_votes = {}

        for fen in self.belief_states:
            board = chess.Board(fen)

            # Try capturing enemy king
            enemy_king = board.king(not self.color)
            if enemy_king:
                attackers = board.attackers(self.color, enemy_king)
                if attackers:
                    move = chess.Move(attackers.pop(), enemy_king)
                    if move in move_actions:
                        move_str = move.uci()
                        move_votes[move_str] = move_votes.get(move_str, 0) + 5  # High value
                        continue

            # Use Stockfish with fallback to alpha-beta
            try:
                result = self.engine.play(board, chengine.Limit(time=0.1))
                if result.move and result.move in move_actions:
                    move_str = result.move.uci()
                    move_votes[move_str] = move_votes.get(move_str, 0) + 1
                    continue
            except:
                pass

            # Use alpha-beta pruning fallback
            best_move = self.alpha_beta_move(board, move_actions, ALPHA_BETA_DEPTH)
            if best_move:
                move_str = best_move.uci()
                move_votes[move_str] = move_votes.get(move_str, 0) + 1

        if not move_votes:
            print("⚠ No good move found — choosing random")
            return random.choice(move_actions)

        best_move_str = max(move_votes.items(), key=lambda x: x[1])[0]
        return chess.Move.from_uci(best_move_str)

    # Alpha-beta move search
    def alpha_beta_move(self, board, legal_moves, depth):
        best_score = float('-inf')
        best_move = None
        for move in legal_moves:
            new_board = board.copy()
            try:
                new_board.push(move)
                score = self.alpha_beta(new_board, depth - 1, float('-inf'), float('inf'), False)
                if score > best_score:
                    best_score = score
                    best_move = move
            except:
                continue
        return best_move

    # Alpha-beta pruning recursive function
    def alpha_beta(self, board, depth, alpha, beta, maximizing):
        if depth == 0 or board.is_game_over():
            return self.evaluate(board)

        moves = list(board.legal_moves)
        if maximizing:
            value = float('-inf')
            for move in moves:
                new_board = board.copy()
                new_board.push(move)
                value = max(value, self.alpha_beta(new_board, depth - 1, alpha, beta, False))
                alpha = max(alpha, value)
                if alpha >= beta:
                    break
            return value
        else:
            value = float('inf')
            for move in moves:
                new_board = board.copy()
                new_board.push(move)
                value = min(value, self.alpha_beta(new_board, depth - 1, alpha, beta, True))
                beta = min(beta, value)
                if beta <= alpha:
                    break
            return value

    # Static evaluation function
    def evaluate(self, board):
        piece_values = {
            chess.PAWN: 1,
            chess.KNIGHT: 3,
            chess.BISHOP: 3,
            chess.ROOK: 5,
            chess.QUEEN: 9,
            chess.KING: 0
        }
        score = 0
        for square in chess.SQUARES:
            piece = board.piece_at(square)
            if piece:
                value = piece_values[piece.piece_type]
                score += value if piece.color == self.color else -value
        return score

    # Updates belief state after move
    def handle_move_result(self, requested_move, taken_move, captured_opponent_piece, capture_square):
        move = taken_move if taken_move else chess.Move.null()
        updated = set()
        for fen in self.belief_states:
            board = chess.Board(fen)
            try:
                board.push(move)
                updated.add(board.fen())
            except:
                continue
        self.belief_states = updated

    # Gracefully shutdown Stockfish
    def handle_game_end(self, winner_color, win_reason, game_history):
        try:
            self.engine.quit()
        except:
            print("⚠ Stockfish already closed")


# Entry point for tournament runner
def create_bot():
    return ImprovedAgent()
